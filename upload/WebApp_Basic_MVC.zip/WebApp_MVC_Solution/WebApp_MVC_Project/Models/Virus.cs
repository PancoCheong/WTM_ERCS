﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Threading.Tasks;

namespace WebApp_MVC_Project.Models
{
    public class Virus
    {
        public string VirusName { get; set; }
        public string VirusCode { get; set; }
    }
}
