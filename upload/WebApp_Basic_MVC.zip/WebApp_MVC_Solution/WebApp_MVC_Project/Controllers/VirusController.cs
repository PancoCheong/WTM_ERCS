﻿using Microsoft.AspNetCore.Mvc;
using WebApp_MVC_Project.Models;

namespace WebApp_MVC_Project.Controllers
{
    // URL = http://localhost:5000/virus
    public class VirusController : Controller
    {

        // URL = http://localhost:5000/virus/index
        public IActionResult Index()
        {
            return View();
        }

        // URL = http://localhost:5000/virus/create
        // HTTP GET by default and use URI name as the method name
        //[HttpGet("/newname")]   //override the URI name  (HTTP ERROR 405 when accessing the old name)
        public IActionResult Create()
        {
            return View();
        }

        // URL = http://localhost:5000/virus/create
        // auto-map input data to model property if its name is the same
        [HttpPost]
        public IActionResult Create(Virus virus)
        {
            //TODO: save to database
            return View("Create2", virus);
        }
    }
}
