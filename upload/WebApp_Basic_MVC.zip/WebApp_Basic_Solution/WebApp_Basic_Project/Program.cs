using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
// new import
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace WebApp_Basic_Concept
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    //webBuilder.UseStartup<Startup>(); //UseStartup() execute the ConfigureServices() and then Configure() in Startup
                    // We can program all the configuration in here and remove the Startup class
                    webBuilder.ConfigureServices(services =>
                    {
                        services.AddResponseCompression();
                    });

                    webBuilder.Configure((bc, x) => {
                        x.UseResponseCompression();

                        x.Use((context, next) => { //HttpContext, next (next Task in Middleware)
                            string html = "";
                            if (context.Request.Path == "/")
                            {
                                html = @"
<html>
<head>
  <meta charset='UTF-8' />
  <link rel='stylesheet' href='StyleSheet.css' />
</head>
<body>
  �w��i�J�f�r�w�޲z<br/>
  <a href='/Virus/Create'>�s�W�f�r</a><br/>
</body>
</html>
";
                                context.Response.ContentType = "text/html"; //specify the return type
                                return context.Response.WriteAsync(html);
                            }
                            if (context.Request.Path == "/Virus/Create")
                            {
                                if (context.Request.Method == "GET")
                                {
                                    html = @"
<html>
<head>
  <meta charset='UTF-8' />
  <link rel='stylesheet' href='StyleSheet.css' />
</head>
<body>
  <form method = 'POST'>
    �f�r�W��:<input name = 'VirusName' /> <br/>
    �f�r�s��:<input name = 'VirusCode' /> <br/>
    <button type='submit'>����</button>
</form>
</body>
</html>
";
                                }

                                if (context.Request.Method == "POST")
                                {
                                    //TODO: save to database
                                    // $@ - dynamic content
                                    html = $@"
<html>
<head>
  <meta charset='UTF-8' />
  <link rel='stylesheet' href='StyleSheet.css' />
</head>
<body>
  ���\�s�W!<br/>
  <form method = 'POST'>
    �f�r�W��:{context.Request.Form["VirusName"]} <br/>
    �f�r�s��:{context.Request.Form["VirusCode"]} <br/>
  <a href='/Virus/Create'>�A���s�W</a><br/>
  <a href='/'>��^����</a><br/>
</form>
</body>
</html>
";
                                }
                                context.Response.ContentType = "text/html"; //specify the return type
                                return context.Response.WriteAsync(html);
                            }

                            // if we don't use app.UseStaticFiles(), this is how it works behind the scene
                            if (context.Request.Path.Value.EndsWith("StyleSheet.css"))
                            {
                                string path = bc.HostingEnvironment.ContentRootPath + "/file/StyleSheet.css";
                                string css = System.IO.File.ReadAllText(path);
                                context.Response.ContentType = "text/css";
                                return context.Response.WriteAsync(css);
                            }

                            // response HTTP 404 status code in header
                            context.Response.StatusCode = 404;
                            return context.Response.WriteAsync("Virus Page is not found!");
                        });
                    });
                });
    }
}
